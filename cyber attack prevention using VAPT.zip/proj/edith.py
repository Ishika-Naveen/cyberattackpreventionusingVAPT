#!usr/bin/env python3

import subprocess
import time
import sys
import os
import getpass
from colorama import Fore, Back, Style

subprocess.call("clear")

print(" @@@@@    @@@@@       @@@@@@@@@@@@       @@@@@@@@@@@@@       @@@@@@@@@@@@@@")
print(" @@@@@    @@@@@       @@@      @@@       @@@        @@            @@@@                   ")
print(" @@@@@    @@@@@       @@@      @@@       @@@        @@            @@@@                     ")
print(" @@@@@    @@@@@       @@@      @@@       @@@        @@            @@@@                       ")
print(" @@@@@    @@@@@       @@@      @@@       @@@        @@            @@@@                       ")
print(" @@@@@    @@@@@       @@@@@@@@@@@@       @@@@@@@@@@@@@            @@@@                               ")
print("  @@@@    @@@@        @@@      @@@       @@@                      @@@@                   ")
print("   @@@@  @@@@         @@@      @@@       @@@                      @@@@                   ")
print("     @@@@@@           @@@      @@@       @@@                      @@@@                  ")
print("       @@             @@@      @@@       @@@                      @@@@        \n  ")

print("\033[3;30;40mVULNERABILITY ASSESSMENT AND PENETRATION TESTING:")

print("\033[1;32;40mDisclaimer:")
print("\033[1;30;40mThe tool must be used for educational purposes only .\nWe do not take respnsibility in case of any misuse of this tool.")
print("You must abide to the terms and are completely responsible for the usage of this tool.\n")


while True:
    passw = getpass.getpass(prompt=(Fore.WHITE + "Enter password to use the interface: "), stream=None)
    
    def animate():
        sys.stdout.write('\rloading |')
        time.sleep(0.1)
        sys.stdout.write('\rloading /')
        time.sleep(0.1)
        sys.stdout.write('\rloading -')
        time.sleep(0.1)
        sys.stdout.write('\rloading \\')
        time.sleep(0.1)
        sys.stdout.write('\rloading |')
        time.sleep(0.1)
        sys.stdout.write('\rloading /')
        time.sleep(0.1)
        sys.stdout.write('\rloading -')
        time.sleep(0.1)
        sys.stdout.write('\rloading \\')
        time.sleep(0.1)
        sys.stdout.write('\rloading |')
        time.sleep(0.1)
        sys.stdout.write('\rloading /')
        time.sleep(0.1)
        sys.stdout.write('\rloading -')
        time.sleep(0.1)
        sys.stdout.write('\rloading \\')
        time.sleep(0.1)
        sys.stdout.write('\rloading /')
        time.sleep(0.1)
        sys.stdout.write('\rloading -')
        time.sleep(0.1)
        sys.stdout.write('\rloading \\')
        time.sleep(0.1)
        sys.stdout.write('\rloading |')
        time.sleep(0.1)
        sys.stdout.write('\rloading /')
        time.sleep(0.1)
        sys.stdout.write('\rloading -')
        time.sleep(0.1)
        sys.stdout.write('\rloading \n')
        
    def action():
        subprocess.call(["python3", "anime1.py"])
    
    passw_verify = getpass.getpass(prompt="Verify the password you just entered: ", stream=None)
    
    if passw == passw_verify and passw == "ISEISE":
        break
    else:
        print("The passwords don't match, please try again.")

print("Password entered:", '*' * len(passw))
animate()
action()

"""print(Fore.RED + "Enter the password : ")
def animate():
        sys.stdout.write('\rloading |')
        time.sleep(0.1)
        sys.stdout.write('\rloading /')
        time.sleep(0.1)
        sys.stdout.write('\rloading -')
        time.sleep(0.1)
        sys.stdout.write('\rloading \\')
        time.sleep(0.1)
        sys.stdout.write('\rloading |')
        time.sleep(0.1)
        sys.stdout.write('\rloading /')
        time.sleep(0.1)
        sys.stdout.write('\rloading -')
        time.sleep(0.1)
        sys.stdout.write('\rloading \\')
        time.sleep(0.1)
        sys.stdout.write('\rloading |')
        time.sleep(0.1)
        sys.stdout.write('\rloading /')
        time.sleep(0.1)
        sys.stdout.write('\rloading -')
        time.sleep(0.1)
        sys.stdout.write('\rloading \\')
        time.sleep(0.1)
        sys.stdout.write('\rloading /')
        time.sleep(0.1)
        sys.stdout.write('\rloading -')
        time.sleep(0.1)
        sys.stdout.write('\rloading \\')
        time.sleep(0.1)
        sys.stdout.write('\rloading |')
        time.sleep(0.1)
        sys.stdout.write('\rloading /')
        time.sleep(0.1)
        sys.stdout.write('\rloading -')
        time.sleep(0.1)
        sys.stdout.write('\rloading \n')
def action():

    subprocess.call(["python3", "anime1.py"])

passw = input("")
if passw == "SVIT":

    animate()
    action()
else:
    print("The password you entered is incorrect. Please try again with the correct password")"""











































#print("These are the categories that are available in this tool:")
#print("Category 1: System modifications")
#print("1.MAC changer\n")


#print("Category 2: Website testing")
#print("2.Website information gathering")
#print("3.Website Vulnerability assessment")
#print("4.Sql injection(Basic version only)\n ")

#print("Category 3: Network testing")
#print("5.WiFi hacking (Wireless card required)")
#print("6.Nmap")
#print("7.Network de-authenticator(Wireless card required)\n")

#print("Category 4: Sniffing and Spoofing")
#print("8.Man-in-the-middle attack")
#print("9.Browser Exploitation framework\n")

#print("Category 5: Social media information gathering")
#print("10.Social media information gathering\n ")




#print("11.OSINT tools (!!Warning!! This is too dangerous and practically illegal")
